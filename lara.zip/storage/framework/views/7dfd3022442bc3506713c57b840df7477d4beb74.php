<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="app-content content ">
                        <!-- pricing free trial -->
                    <div class="pricing-free-trial">
                        <div class="row">
                            <div class="col-12 col-lg-10 col-lg-offset-3 mx-auto">
                                <div class="pricing-trial-content d-flex justify-content-between">
                                    <div class="text-center text-md-left mt-3">
                                        <h3 class="text-primary">Still not convinced ? </h3>
                                        <h5>Your money will be secured with 100% refund policy</h5>
                                        <a href="/browse" class="btn btn-primary mt-2 mt-lg-3" role="button">Browse Plan's
                      </a>
                                    </div>

                                    <!-- image -->
                                    <img src="<?php echo e(asset('/images/illustration/pricing-Illustration.svg')); ?>" class="pricing-trial-img img-fluid" alt="svg img" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ pricing free trial -->
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/Download/lara/resources/views/welcome.blade.php ENDPATH**/ ?>